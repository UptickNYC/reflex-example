import reflex as rx

config = rx.Config(
    app_name="reflex_example",
    api_url="https://playful-mooncake-139f1e.netlify.app:8000",
)